<?php
session_start();
    require_once('database.php');
    $product = get_products();
    if(isset($_POST['keyword'])) {
        header('Location: search.php?sanpham=' . $_POST['keyword']);
    }
    $delivery = get_delivery();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="SE.css">
    <link rel="stylesheet" href="Banner.css">
    <link rel="stylesheet" href="Notification.css">
    <link rel="stylesheet" href="cart.css">
    <link rel="stylesheet" href="ShowProduct.css">
    <link rel="stylesheet" href="LastLine.css">
    <link rel="stylesheet" href="suggestion.css">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
</head>
<body>
    <div id="suggestions" class="suggestions"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="navbar-wrapper container-wrapper">
                <nav class="container-navbar">
                <div class="nav-item item-1">
                        <a class="nav-link" style="text-decoration: none;color: #fff;" target="_blank" rel="noopener noreferrer" href="#">Your Profile</a>
                        <span style="font-size: 1.2em;margin-right: 12px;color: #fff;">|</span>
                        <div style="color: #fff;" class="connection">Connect
                            <i style="color: white;font-size: 1.2em;" class="facebook bi bi-facebook"></i>
                        </div>
                    </div>

                    <div class="nav-item item-2">
                        <div class="navbar-text notification">
                            <i class="bi bi-bell"></i>
                            <span>Notification</span>
                            <ul class="show-notification"></ul>
                        </div>
                        <div class="navbar-text support">
                            <i class="bi bi-question-circle"></i>
                            <span>Support</span>
                        </div>
                        <div class="navbar-text language">
                            <i class="bi bi-translate"></i>
                            <span>English</span>
                            <ul class="show-language"></ul>
                        </div>
                        <?php
                            if (isset($_SESSION['name'])){
                        ?>
                            <div class="navbar-text"><?php echo $_SESSION['name'] ?></div>
                            <div class="navbar-text" type="button" onclick="logoutbtn()">Logout</div>
                        <?php 
                            }else{
                        ?> 
                            <div class="navbar-text sign-up">Register</div>
                            <span class="navbar-text" style="font-size: 1.2em;">|</span>
                            <div class="navbar-text sign-in">Sign In</div>
                        <?php
                            }
                        ?>
                    </div>
                </nav>
                <div style="display: flex;align-items: center;">
                <a style="font-size: 1.5em;text-decoration: none;margin-left: 5%;border: 1px solid #fff;color:#fff;padding: 3px 15px;" href="SE.php">HOME</a>
                    <form style="padding: 0px 0px 0px 5px;height: 50%;margin-right:10%;" method="post" class="row-2 search-box form-inline">
                        <!-- SEARCH -->
                        <input id="search-input" value="" class="search" name="keyword" type="text" placeholder="Searching products"
                        aria-label="Search" aria-describedby="button-addon2">
                        <button type="btn" class="btn" id="button-addon2">
                        <i class="bi bi-search"></i>
                        </button>
                        
                    </form>
                        <a href="cart.php" class="navbar-text cart"><i class="bi bi-cart"></i></a>
                </div>
            </div>
        </div>

        <div class="row-3">
            <div class="cart-wrapper" >
                <br>
                    <div class="ThuocTinhSP">
                        <div class="container-CTSP" style="width:160vh;">
                            <div class="ChiTiet-SP">
                                <div style="margin-left:10%;">Products</div>
                                <div style="margin-right:6%;">Delivery date</div>
                                <div style="margin-right:6%;">Date of receipt</div>
                                <div style="margin-right:6%;">Status</div>
                            </div>
                        </div>
                    </div>
                <div class="NoiDung">
                    <br>
                    <?php
                    if(!empty($delivery)) {
                        foreach($delivery as $d) {
                    ?>
                    <div class="SanPhams" style="margin-top:0.2%;" data-id="<?=$d['id']?>">
                        <div class="Check-SP" style="width:40%;">
                            <img src="./image/<?=$d['productID']?>.jpg" style="width:50px;height:50px;">
                            <label style="font-size: 1.2em;font-weight:500;"><?=$d['Name']?></label>
                        </div>
                        <div class="container-SPS" style="width: 100%;">
                            <div class="ChiTiet-SPS">
                                <div class="NgayGiao" style="font-size:1.2em;margin-left:4%;"><?=$d['NgayGiao']?></div>
                                <div class="NgayNhan" style="font-size:1.2em;"><?=$d['NgayNhan']?></div>
                                <div class="Status" style="font-size:1.2em;margin-right:7%;color:green;"><?=$d['status']?></div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    } else {
                        ?>
                            <div class="SanPhams" style="justify-content: center;align-items:center;">
                                <div style="font-size:1.2em;opacity:0.6;">There's is no products</div>
                            </div>
                        <?php
                    }
                    ?>
                    
                </div>
                <br><br><br>

                <div class="More-product">
                    <p>More Product</p>
                    <?php
                        foreach($product as $p) {
                            $dongia = number_format($p['dongia'], 0, " ", ".");
                    ?>
                        <div class="Products" data-id="<?=$p['maSP']?>" data-title="<?=$p['tenSP']?>"
                        data-price="<?=$p['dongia']?>" data-soluong="<?=$p['sl']?>" 
                        data-nsx="<?=$p['nsx']?>" data-mota="<?=$p['mota']?>" data-image="./image/<?=$p['maSP']?>.jpg">
                            <div class="card-wrapper">
                                <div class="card">
                                <img class="card-img-top" src="./image/<?=$p['maSP']?>.jpg" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title"><?=$p['tenSP']?></h4>
                                        <i class="bi bi-ticket"> Discount 200đ</i>
                                        <p class="card-text"><?=$dongia?>đ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                        }
                    ?>
                </div>
                <hr style="height: 5px;margin-top: 10%;color: rgb(221, 0, 0)" class="Last-Line">
            </div>
        </div>
    </div>

</body>
<script src="SE.js"></script>
<script src="SearchHint.js"></script>
<script src="Product.js"></script>
<script>
    function logoutbtn(){
        window.location.href = 'logout.php';
    }
</script>
</html>