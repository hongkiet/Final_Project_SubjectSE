const Product = document.querySelectorAll('.Products');
Product.forEach(SP => {
    SP.addEventListener('click', () => {
        const soluong = SP.dataset.soluong;
        const title = SP.dataset.title;
        const price = SP.dataset.price;
        const nsx = SP.dataset.nsx;
        const mota = SP.dataset.mota;
        const image = SP.dataset.image
        window.location.assign(`SanPham.php?name=${title}&anh=${image}`);
    });
});