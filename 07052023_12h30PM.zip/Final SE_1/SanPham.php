<?php
    $image = $_GET['anh'];
    require_once('connection.php');
    if(isset($_GET['name'])) {
        $name = $_GET['name'];
        $conn = connect_to_db();
        $products = [];
        $sql = $conn->query("SELECT * FROM product where tenSP like '$name'");
        if ($sql === false) {
            // xử lý lỗi nếu có
            echo "Lỗi truy vấn SQL: " . $conn->error;
            exit;
        } elseif ($sql->num_rows > 0) {
            $result = $sql->fetch_assoc();
            $id = $result['maSP'];
            $price = $result['dongia'];
            $name = $result['tenSP'];
            $nsx = $result['nsx'];
            $soluong = $result['sl'];
            $mota = $result['mota'];
        } else {
            // xử lý trường hợp không có kết quả trả về
            echo "Không có sản phẩm nào phù hợp";
            exit;
        }
    }
    
    require_once('database.php');
    $product = get_products();
    if(isset($_POST['keyword'])) {
        header('Location: search.php?sanpham=' . $_POST['keyword']);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="SE.css">
    <link rel="stylesheet" href="Banner.css">
    <link rel="stylesheet" href="Notification.css">
    <link rel="stylesheet" href="cart.css">
    <link rel="stylesheet" href="ShowProduct.css">
    <link rel="stylesheet" href="LastLine.css">
    <link rel="stylesheet" href="Specific_SP.css">
    <link rel="stylesheet" href="suggestion.css">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
</head>
<body>
    <div id="suggestions" class="suggestions"></div>
    <div class="DaThemVaoGio" style="z-index: 9999;position:absolute;margin-left: 40%;width: 15%;
                        border: 1px solid green;height:20%;text-align:center;background-color: black;
                        display:none;justify-content:center;;align-items:center;opacity: 0.8;margin-top: 20%;">
        <i style="color:green;font-size: 3em;" class="bi bi-check-circle"></i>
        <div style="color: #fff;margin-left: 2%;">Added to cart</div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="navbar-wrapper container-wrapper">
                <nav class="container-navbar">
                <div class="nav-item item-1">
                        <a class="nav-link" style="text-decoration: none;color: #fff;" target="_blank" rel="noopener noreferrer" href="#">Your Profile</a>
                        <span style="font-size: 1.2em;margin-right: 12px;color: #fff;">|</span>
                        <div style="color: #fff;" class="connection">Connect
                            <i style="color: white;font-size: 1.2em;" class="facebook bi bi-facebook"></i>
                        </div>
                    </div>

                    <div class="nav-item item-2">
                        <div class="navbar-text notification">
                            <i class="bi bi-bell"></i>
                            <span>Notification</span>
                            <ul class="show-notification"></ul>
                        </div>
                        <div class="navbar-text support">
                            <i class="bi bi-question-circle"></i>
                            <span>Support</span>
                        </div>
                        <div class="navbar-text language">
                            <i class="bi bi-translate"></i>
                            <span>English</span>
                            <ul class="show-language"></ul>
                        </div>
                        <?php
                            if (isset($_SESSION['name'])){
                        ?>
                            <div class="navbar-text"><?php echo $_SESSION['name'] ?></div>
                            <div class="navbar-text" type="button" onclick="logoutbtn()">Logout</div>
                        <?php 
                            }else{
                        ?> 
                            <div class="navbar-text sign-up">Register</div>
                            <span class="navbar-text" style="font-size: 1.2em;">|</span>
                            <div class="navbar-text sign-in">Sign In</div>
                        <?php
                            }
                        ?>
                    </div>
                </nav>
                <div style="display: flex;align-items: center;">
                <a style="font-size: 1.5em;text-decoration: none;margin-left: 5%;border: 1px solid #fff;color:#fff;padding: 3px 15px;" href="SE.php">HOME</a>
                    <form style="padding: 0px 0px 0px 5px;height: 50%;margin-right:10%;" method="post" class="row-2 search-box form-inline">
                        <!-- SEARCH -->
                        <input id="search-input" value="" class="search" name="keyword" type="text" placeholder="Tìm kiếm sản phẩm"
                        aria-label="Search" aria-describedby="button-addon2">
                        <button type="btn" class="btn" id="button-addon2">
                        <i class="bi bi-search"></i>
                        </button>
                        
                    </form>
                        <a href="cart.php" class="navbar-text cart"><i class="bi bi-cart"></i></a>
                </div>
            </div>
        </div>
        <!-- <br><br><br><br><br><br> -->
        <div class="row-3">
            <div class="cart-wrapper" style="width: 90%;">
                <div class="Specific-SP" style="z-index: 0;">
                    
                    <div class="Image-Specific-SP">
                        <img class="Detail-image" src="<?=$image?>" alt="">
                        <div style="display: flex;align-items: center;margin-top: 1%;">
                            <div class="Share">Share:</div>
                            <!-- SHARE -->
                            <i style="color: blue;font-size: 1.5em;" class="share-fb bi bi-facebook"></i>
                        </div>
                        <script>
                            const sharefacebook = document.querySelector('.share-fb');
                            const url = window.location.href;
                            const cleanUrl = url.replace("https://", "");
                            sharefacebook.addEventListener('click', () => {
                                window.open('https://facebook.com/sharer/sharer.php?u=' + window.location.href);
                            });
                        </script>
                    </div>
                    <div class="detail-information">
                        <div class="sp-title"><?=$name?></div>
                        <div class="price"><?=$price?>đ</div>
                        <div style="margin-top: 7%;">
                            <div style="display: flex;justify-content: space-between;">
                                <div>Insurance</div>
                                <div>Consumer Benefit Insurance <a style="text-decoration: none;" href="">More Information</a></div>
                            </div>
                            <div class="delivery" style="display: flex;justify-content: space-between;margin-top: 5%;">
                                <div>Transport</div>
                                <div style="display: flex;justify-content: space-between;">
                                    <img style="width: 8%;height: 30%;" src="https://deo.shopeemobile.com/shopee/shopee-pcmall-live-sg/74f3e9ac01da8565c3baead996ed6e2a.png" alt="">
                                    <div>
                                        <div style="font-size: 0.8em;">Free Ship</div>
                                        <div style="font-size: 0.8em;">Free shipping for orders over 99,000 VND</div>
                                        <div style="display: flex;justify-content: space-between;margin-top: 3%;">
                                            <i style="font-size: 0.8em;" class="bi bi-truck"> Transport to</i>
                                            <div>Address</div>
                                        </div>
                                        <div style="display: flex;justify-content: space-between;margin-top: 2%;align-items: center;">
                                            <div style="margin-left: 6%;font-size: 1em;">Transport fee</div>
                                            <div style="font-size: 0.9em;">0đ - 22.000đ</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="SoLuong" style="display: flex;justify-content: space-between;margin-top: 10%;">
                                <div>Số lượng</div>
                                <div style="opacity: 0.6;">Remaining: <?=$soluong?></div>
                                <div style="display: flex;border: 0.2px solid black;justify-content: center;width: 30%;align-items: center;">
                                    
                                    <div style="margin-right: 10%;font-size: 1.2em;" class="Bot">-</div>
                                    <input class="NhapSoLuong" value="" type="text">
                                    <div style="margin-left: 10%;font-size: 1.2em;" class="Them">+</div>
                                </div>
                            </div>
                            <div class="giohang" style="margin-top: 20%;display: flex;">
                                <button class="themvaogiohang" data-name="<?=$name?>"
                                style="border: 1px solid rgb(255, 85, 0);padding: 10px 15px 10px 15px;border-radius: 5px;
                                background-color: rgb(244, 238, 235);font-size: 1.3em;color:rgb(255, 85, 0);">
                                <i class="bi bi-cart-plus"></i> Add to cart</button>
                                
                                <button class="muangay" style="margin-left: 5%;border: 1px solid rgb(255, 85, 0);padding: 10px 15px 10px 15px;
                                border-radius: 5px;background-color: rgb(223, 74, 0);font-size: 1.2em;color:rgb(255, 255, 255);" type="button">Purchase</button>
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="product-detail">
                    <div class="detail">
                        <p style="font-size: 1.2em;font-weight: 500;">Product Detail</p>
                        <div style="display: flex; justify-content: space-between;">
                            <div>Manufacturer</div>
                            <div><?=$nsx?></div>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <div>Product's name</div>
                            <div><?=$name?></div>
                        </div>
                    </div>
                    <div class="Product-Description" style="margin-top: 2%;">
                        <p style="font-size: 1.2em;font-weight: 500;">DESCRIPTION</p>
                        <div style="width:100%;white-space:pre;"><?=$mota?></div>
                    </div>
                </div>
                
                <div class="Rating-product">
                    <p style="margin-left: 3%;padding-top: 3%;font-size: 1.2em;font-weight: 500;">Review</p>
                    <div class="DanhGia">
                        <p>5.0 / 5</p>
                        <div class="rate">
                            <span class="star" data-star="1">&#9733;</span>
                            <span class="star" data-star="2">&#9733;</span>
                            <span class="star" data-star="3">&#9733;</span>
                            <span class="star" data-star="4">&#9733;</span>
                            <span class="star" data-star="5">&#9733;</span>
                        </div>
                    </div>
                    
                </div>

                <div class="More-product">
                    <?php
                        foreach($product as $p) {
                            $dongia = number_format($p['dongia'], 0, " ", ".");
                    ?>
                        <div class="Products" data-id="<?=$p['maSP']?>" data-title="<?=$p['tenSP']?>"
                        data-price="<?=$p['dongia']?>" data-soluong="<?=$p['sl']?>" 
                        data-nsx="<?=$p['nsx']?>" data-mota="<?=$p['mota']?>" data-image="./image/<?=$p['maSP']?>.jpg">
                            <div class="card-wrapper">
                                <div class="card">
                                <img class="card-img-top" src="./image/<?=$p['maSP']?>.jpg" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title"><?=$p['tenSP']?></h4>
                                        <i class="bi bi-ticket"> Discount 200đ</i>
                                        <p class="card-text"><?=$dongia?>đ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                        }
                    ?>
                </div>
                <hr style="height: 5px;margin-top: 10%;color: rgb(221, 0, 0)" class="Last-Line">
            </div>
            
        </div>
    </div>
    
    
      
	
</body>
<script>
    const them = document.querySelector('.Them');
    const bot = document.querySelector('.Bot');
    const Soluong = document.querySelector('.NhapSoLuong');
    const limit = <?=$soluong?>;
    Soluong.value = 1;
    them.addEventListener('click', () => {
        if (Soluong.value < limit) {
            Soluong.value = parseInt(Soluong.value) + 1;
        }
    });

    bot.addEventListener('click', () => {
        if (Soluong.value > 0) {
            Soluong.value = parseInt(Soluong.value) - 1;
        }
    });

    const themvaogio = document.querySelector('.themvaogiohang');
    const div = document.querySelector('.DaThemVaoGio');
    let isShown = true;

    function ThemVaoGioHang() {
        div.style.display = 'flex';
        if(isShown == true) {
            setTimeout(() => {
                div.style.display = 'none';
            }, 3000);
        }  
        const productName = themvaogio.dataset.name;
        const xhr = new XMLHttpRequest();
        xhr.open('GET', `themvaogiohang.php?productName=${encodeURIComponent(productName)}&soluong=${encodeURIComponent(Soluong.value)}`);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                console.log('Added to cart successfully!');
            } else {
                console.log('Failed to add to cart');
            }
        };
        xhr.send();
    }

themvaogio.addEventListener('click', ThemVaoGioHang);

</script>
<script src="SE.js"></script>
<script src="Product.js"></script>
<script src="SearchHint.js"></script>
<script src="rating.js"></script>
</html>