<?php
    session_start();
    session_destroy();
    header("Location: SE.php");
    exit; 
?>