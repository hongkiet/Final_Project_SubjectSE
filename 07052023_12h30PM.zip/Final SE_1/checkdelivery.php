<?php
    require_once('connection.php');
    $conn = connect_to_db();
    
        $getdata = $conn->query("SELECT * FROM cart");
        $products = [];
        while ($row = $getdata->fetch_assoc()) {
            $products[] = $row;
        }
        $rand_id = random_int(0, 999);
        foreach ($products as $product) {
            $new_id = $rand_id;
            $productName = $product['productName'];
            $productID = $product['productId'];
            $soluong = $product['soluong'];
            $today = date('d-m-Y');
            $receiveDate = date('d-m-Y', strtotime('+3 days'));
            $sql = "INSERT INTO delivery (id,Name, NgayGiao, NgayNhan, status, productID) VALUES ('$new_id', '$productName', NOW(), DATE_ADD(NOW(), INTERVAL 3 DAY), 'Processing', '$productID')";
            $update = $conn->query("UPDATE product set sl = sl - '$soluong' WHERE tenSP like '$productName'");
            if ($conn->query($sql) === TRUE) {
                echo "Product added to delivery successfully";
            } else {
                echo "Error adding product to delivery: " . $conn->error;
            }
        }
        $sql = $conn->query("DELETE FROM cart");
?>
