<?php
    require_once('database.php');
    
    $error = '';
    $email = '';
    if (isset($_POST['email'])) {
        $email = $_POST['email'];
        if (empty($email)) {
            $error = 'Please enter your email';
        } else if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
            $error = 'This is not a valid email address';
        }
        else {
            $result = ForgotPassword($email);
            // echo 'good';
            if($result['code'] == 0) {
                header('Location: SE.php');
            } else if($result['code'] == 1) {
                $error = 'Invalid Email!.';
            } else {
                // $error = $result['error'];
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="DangNhap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="navbar-wrapper header">
                <nav class="container-navbar">
                    <a class="navbar-text home" href="SE.php">Home</a>
                    <div class="navbar-text sign-up">Reset Password</div>
                    <a href="#" class="navbar-text help">You need help?</a>
                </nav>
            </div>
            <div class="navbar-wrapper content" style="display: flex;justify-content: center;align-items: center;">
                <div class="signup-form" style="border-radius: 5px;">
                    <h2>Reset Password</h2>
                    <form novalidate method="post">
                      <div class="form-group">
                        <input name="email" type="text" class="form-control" placeholder="Email" required="required">
                      </div>
                      <div class="form-group">
                      <?php
                          if (!empty($error)) {
                              echo "<div class='alert alert-danger'>$error</div>";
                          }
                      ?>
                        <button type="submit" class="btn btn-primary btn-block btn-lg">Reset</button>
                      </div>
                    </form>
                  </div>
                  
            </div>
            <div class="navbar-wrapper more-infomation">

            </div>
        </div>
    </div>
</body>
</html>