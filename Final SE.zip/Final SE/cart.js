const them = document.querySelector('.Them');
const bot = document.querySelector('.Bot');
const Soluong = document.querySelector('.NhapSoLuong');
Soluong.value = 1;
them.addEventListener('click', () => {
    Soluong.value = parseInt(Soluong.value) + 1;
});
bot.addEventListener('click', () => {
    Soluong.value = parseInt(Soluong.value) - 1;
});

const muangay = document.querySelector('.muangay');
muangay.addEventListener('click', () => {
    window.location.assign('cart.html');
});

