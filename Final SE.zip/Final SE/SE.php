<?php
    require_once('database.php');
    $product = get_products();
    if(isset($_POST['keyword'])) {
        header('Location: search.php?sanpham=' . $_POST['keyword']);
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="SE.css">
    <link rel="stylesheet" href="Banner.css">
    <link rel="stylesheet" href="Notification.css">
    <link rel="stylesheet" href="cart.css">
    <link rel="stylesheet" href="ShowProduct.css">
    <link rel="stylesheet" href="LastLine.css">
    <link rel="stylesheet" href="suggestion.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
</head>

<body>
    <div id="suggestions" class="suggestions"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="navbar-wrapper container-wrapper">
                <nav class="container-navbar">
                    <div class="nav-item item-1">
                        <a class="nav-link" style="text-decoration: none;color: #fff;" target="_blank" rel="noopener noreferrer" href="#">Kênh Người Bán</a>
                        <span style="font-size: 1.2em;margin-right: 12px;color: #fff;">|</span>
                        <div style="color: #fff;" class="connection">Kết nối 
                            <i style="color: white;font-size: 1.2em;" class="facebook bi bi-facebook"></i>
                        </div>
                    </div>

                    <div class="nav-item item-2">
                        <div class="navbar-text notification">
                            <i class="bi bi-bell"></i>
                            <span>Thông báo</span>
                            <ul class="show-notification"></ul>
                        </div>
                        <div class="navbar-text support">
                            <i class="bi bi-question-circle"></i>
                            <span>Hỗ trợ</span>
                        </div>
                        <div class="navbar-text language">
                            <i class="bi bi-translate"></i>
                            <span>Tiếng Việt</span>
                            <ul class="show-language"></ul>
                        </div>
                        <div class="navbar-text sign-up">Đăng Ký</div>
                        <span class="navbar-text" style="font-size: 1.2em;">|</span>
                        <div class="navbar-text sign-in">Đăng Nhập</div>
                    </div>
                </nav>
                <div style="display: flex;align-items: center;justify-content: space-between;">
                    <form style="padding: 0px 0px 0px 5px;height: 50%;" method="post" class="row-2 search-box form-inline">
                        <!-- SEARCH -->
                        <input id="search-input" value="" class="search" name="keyword" type="text" placeholder="Tìm kiếm sản phẩm"
                        aria-label="Search" aria-describedby="button-addon2">
                        <button type="btn" class="btn" id="button-addon2">
                        <i class="bi bi-search"></i>
                        </button>
                        
                    </form>
                        <a href="cart.php" class="navbar-text cart"><i class="bi bi-cart"></i></a>
                </div>
            </div>
        </div>
        <!-- <br><br><br><br><br><br> -->
        <div class="row-3">
            <div class="cart-wrapper" style="width: 100%;">
                
                    <div class="swiper mySwiper" style="position: relative;z-index: 0;width: 100%;border: 1px solid black;background-color: #fff;
                    margin-top: 5%;height: 50vh;">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide"><img style="width: 100%;height: 100%;" src="AKK.png" alt=""></div>
                            <div class="swiper-slide"><img style="width: 100%;height: 100%;" src="https://ik.imagekit.io/tvlk/blog/2018/11/mon-an-vat-ngon-ha-noi-1.jpg?tr=dpr-2,w-675" alt=""></div>
                            <div class="swiper-slide"><img style="width: 100%;height: 100%;" src="AKK.png" alt=""></div>
                            <div class="swiper-slide"><img style="width: 100%;height: 100%;" src="https://ik.imagekit.io/tvlk/blog/2018/11/mon-an-vat-ngon-ha-noi-1.jpg?tr=dpr-2,w-675" alt=""></div>
                        </div>

                            <div style="color: grey;opacity: 0.5;transform: scale(1.5);" class="swiper-button-next"></div>
                            <div style="color: grey;opacity: 0.5;transform: scale(1.5);" class="swiper-button-prev"></div>
                            <div style="position: absolute;width: 100%;bottom:0;" class="swiper-pagination"></div>
                    </div>
               
                    <div class="DanhMuc" style="margin-top: 5%;background-color: #fff;width: 100%;height: fit-content;padding: 20px;">
                        <div>Danh Mục</div>
                        <div style="display: flex;">
                            <div class="card-wrapper">
                                <div class="card">
                                    <img class="card-img-top" src="https://down-vn.img.susercontent.com/file/687f3967b7c2fe6a134a2c11894eea4b_tn" alt="Card image">
                                    <div class="card-body">
                                        <p class="card-text">Thời trang nam</p>
                                      </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <div class="More-product">
                    <?php
                        foreach($product as $p) {
                    ?>
                        <div class="Products" data-id="<?=$p['maSP']?>" data-title="<?=$p['tenSP']?>"
                        data-price="<?=$p['dongia']?>" data-soluong="<?=$p['sl']?>" 
                        data-nsx="<?=$p['nsx']?>" data-mota="<?=$p['mota']?>">
                            <div class="card-wrapper">
                                <div class="card">
                                    <img class="card-img-top" src="https://ik.imagekit.io/tvlk/blog/2018/11/mon-an-vat-ngon-ha-noi-1.jpg?tr=dpr-2,w-675" alt="Card image">
                                    <div class="card-body">
                                        <h4 class="card-title"><?=$p['tenSP']?></h4>
                                        <i class="bi bi-ticket"> Giảm 200đ</i>
                                        <p class="card-text"><?=$p['dongia']?>đ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                        }
                    ?>
                </div>
                <hr style="height: 5px;margin-top: 10%;color: rgb(221, 0, 0)" class="Last-Line">
            </div>
        </div>
    </div>
    
    
      
	
</body>
<script src="SE.js"></script>
<script src="Product.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script src="SearchHint.js"></script>
<script>
    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 4,
    spaceBetween: 10,
    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    breakpoints:{
        0: {
            slidesPerView: 0,
        },
        500: {
            slidesPerView: 1,
        },
        2000: {
            slidesPerView: 5,
        }
    },
    });
  </script>
</html>