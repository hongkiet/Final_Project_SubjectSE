// const sharefacebook = document.querySelector('.share-fb');
// sharefacebook.addEventListener('click', () => {
//     window.open('facebook.com/sharer/sharer.php?u=' + window.location.href);
// });