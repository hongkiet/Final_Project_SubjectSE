const TheTD = document.getElementById('TheTD');
const TheND = document.getElementById('TheND');
const Cash = document.getElementById('Cash');
const cha = document.querySelector('.payment-mode');
const div = document.createElement('div');
TheTD.addEventListener('click', () => {
    cha.innerHTML = '';
    TheTD.classList.add('TheTD-selected');
    TheND.classList.remove('TheND-selected');
    Cash.classList.remove('Cash-selected');
    cha.innerHTML = `
        <div class="Credit-card" style="padding-top: 2%;padding-bottom:2%;"> 
            <div style="border-radius: 3px;width:30%;margin-left:35%;padding:15px;max-height: fit-content;padding-bottom:4%;
            background-color:lightgrey;min-height:55vh;">
                <div style="margin-top: 5%;font-size:1.5em;font-weight:500;">Thêm thẻ</div>
                <div style="margin-top: 5%;font-size:1.2em;font-weight:400;opacity:0.7;">Chi tiết thẻ</div>
                <input style="margin-top: 5%;padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Số thẻ">
                <div style="display:flex;justify-content:space-between;margin-top:5%;">
                    <input style="padding:10px;width:70%;border-radius:10px;" type="text" placeholder="Ngày hết hạn (MM/YY)">
                    <input style="padding:10px;width:25%;border-radius:10px;" type="text" placeholder="Mã CVV">
                </div>
                <input style="margin-top: 5%;padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Họ và tên chủ thẻ">
                <div style="margin-top: 5%;">Địa chỉ đăng ký thẻ Tín dụng</div>
                <div style="margin-top: 5%;">
                    <input style="padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Địa chỉ">
                </div>
                <div style="margin-top: 5%;">
                    <input style="padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Mã bưu chính">
                </div>
            </div>
        </div>
    `
});

TheND.addEventListener('click', () => {
    cha.innerHTML = '';
  TheND.classList.add('TheND-selected');
  TheTD.classList.remove('TheTD-selected');
  Cash.classList.remove('Cash-selected');

  cha.innerHTML = `
    <div class="Bank-type" style="margin-left: 3%;max-height: fit-content;padding-bottom: 3%;">
        <div class="Vietcombank">
            <label for="Vietcombank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Vietcombank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_vietcombank.png" alt="">
                <div style="margin-left:1%;">Vietcombank - Ngân hàng Ngoại Thương</div>
            </label>
        </div>

        <div class="Vietinbank">
            <label for="Vietinbank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Vietinbank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_vietinbank.png" alt="">
                <div style="margin-left:1%;">Vietinbank - Ngân hàng Công Thương</div>
            </label>
        </div>

        <div class="Agribank">
            <label for="Agribank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Agribank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_agribank.png" alt="">
                <div style="margin-left:1%;">Agribank - Ngân hàng Nông Nghiệp</div>
            </label>
        </div>

        <div class="Sacombank">
            <label for="Sacombank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Sacombank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_sacombank.png" alt="">
                <div style="margin-left:1%;">Sacombank - Ngân hàng TMCP Sài Gòn Thương Tín</div>
            </label>
        </div>

        <div class="BIDV">
            <label for="BIDV-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="BIDV-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_bidv.png" alt="">
                <div style="margin-left:1%;">BIDV - Ngân hàng đầu tư và phát triển Việt Nam</div>
            </label>
        </div>

        <div class="TechcomBank">
            <label for="TechcomBank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="TechcomBank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_techcombank.png" alt="">
                <div style="margin-left:1%;">TechcomBank - Ngân hàng Kỹ thương Việt Nam</div>
            </label>
        </div>

        <div class="ACB">
            <label for="ACB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="ACB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_acb.png" alt="">
                <div style="margin-left:1%;">ACB - Ngân hàng ACB</div>
            </label>
        </div>

        <div class="VPBank">
            <label for="VPBank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="VPBank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_vpbank.png" alt="">
                <div style="margin-left:1%;">VPBank - Ngân hàng Việt Nam Thịnh vượng</div>
            </label>
        </div>

        <div class="Đông Á Bank">
            <label for="DongABank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="DongABank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_dongabank.png" alt="">
                <div style="margin-left:1%;">Đông Á Bank - Ngân hàng Đông Á</div>
            </label>
        </div>

        <div class="OceanBankk">
            <label for="OceanBank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="OceanBank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_oceanbank.png" alt="">
                <div style="margin-left:1%;">OceanBank - Ngân hàng Đại Dương</div>
            </label>
        </div>

        <div class="Eximbank">
            <label for="Eximbank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Eximbank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_eximbank.png" alt="">
                <div style="margin-left:1%;">Eximbank - Ngân hàng EximBank</div>
            </label>
        </div>

        <div class="SCB">
            <label for="SCB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="SCB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_scb.png" alt="">
                <div style="margin-left:1%;">SCB - Ngân hàng TMCP Sài Gòn</div>
            </label>
        </div>

        <div class="OCB">
            <label for="OCB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="OCB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_ocb.png" alt="">
                <div style="margin-left:1%;">OCB - Ngân hàng Phương Đông</div>
            </label>
        </div>

        <div class="ABB">
            <label for="ABB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="ABB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_abb.png" alt="">
                <div style="margin-left:1%;">ABB - Ngân hàng TMCP An Bình</div>
            </label>
        </div>

        <div class="MB">
            <label for="MB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="MB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_mb.png" alt="">
                <div style="margin-left:1%;">MB - Ngân hàng Quân Đội</div>
            </label>
        </div>
    </div>
  `
});

Cash.addEventListener('click', () => {
    cha.innerHTML = '';
  Cash.classList.add('Cash-selected');
  TheTD.classList.remove('TheTD-selected');
  TheND.classList.remove('TheND-selected');
  cha.innerHTML = `
    <div style="display:flex;align-items:center;padding-top:2%;margin-left: 10%;">
        <div style="margin-right:10%;">Thanh toán khi nhận hàng</div>
        <div>Phí thu hộ: ₫0 VNĐ. Ưu đãi về phí vận chuyển (nếu có) áp dụng cả với phí thu hộ.</div>
    </div>
  `;
});

const shopvoucher = document.querySelector('.final-Enter-Voucher');
const voucher = document.querySelector('.Voucher-selected');
const Confirmvoucher = document.querySelector('.confirm-voucher');
let isVoucher = true;
shopvoucher.addEventListener('click', () => {
        isVoucher = false;
        voucher.style.display = "flex"
});
Confirmvoucher.addEventListener('click', () => {
    voucher.style.display = "none";
});
const inputVoucher = document.querySelector('.input-voucher');
const ApDungVoucher = document.querySelector('.ApDungVoucher');
inputVoucher.addEventListener('input', function() {
    const inputValue = this.value.trim();
    console.log(inputValue);
    if (inputValue === '') {
        ApDungVoucher.disabled = true;
        return;
    }
    ApDungVoucher.disabled = false;
});
