const facebook = document.querySelector('.facebook');
const DangKy = document.querySelector('.sign-up');
const DangNhap = document.querySelector('.sign-in');
facebook.addEventListener("click", () => {
    window.open('https://www.facebook.com/Hanh.January/');
});
DangKy.addEventListener("click", () => {
    window.location.href = 'dangky.html';
});
DangNhap.addEventListener("click", () => {
    window.location.href = 'DangNhap.html';
});

const notification = document.querySelector('.notification');
const show_notification = document.querySelector('.show-notification');
let isNotification = true;
notification.addEventListener('click', ShowNotification);
function ShowNotification() {
    if(isNotification == true) {
        show_notification.innerHTML = `<div style="z-index: 9999;position:absolute;background-color: white;height: 400px;width:400px;padding:10px;border:0.5px solid black;left:46.5%;display:flex;justify-content:center;align-items:center;">
                                            <div style="color: black;font-size: 1.1em;">Đăng nhập để xem thông báo</div>
                                        </div>
                                    `;
        isNotification = false;
    } else {
        show_notification.innerHTML = '';
        isNotification = true;
    }
}
function RemoveShowNotification() {
    notification.removeEventListener('click', ShowNotification)
}

const cart = document.querySelector(".cart");
setTimeout( () => {
    div.remove();
}, 3000);