// Import thư viện google-auth-library
const {OAuth2Client} = require('google-auth-library');
const client = new OAuth2Client(CLIENT_ID);

// Lấy token từ frontend
const idToken = req.body.id_token;

// Xác thực token với Google
async function verify() {
  const ticket = await client.verifyIdToken({
      idToken: idToken,
      audience: CLIENT_ID,
  });
  const payload = ticket.getPayload();
  const userId = payload['sub'];

  // Lấy thông tin người dùng
  const userData = {
    name: payload.name,
    email: payload.email,
    picture: payload.picture,
  }

  // Trả về thông tin người dùng
  return userData;
}

// Sử dụng async/await để lấy thông tin người dùng
async function loginWithGoogle() {
  try {
    const userData = await verify();
    // Thực hiện các hành động sau khi lấy được thông tin người dùng
    // ...
  } catch (error) {
    console.error(error);
  }
}