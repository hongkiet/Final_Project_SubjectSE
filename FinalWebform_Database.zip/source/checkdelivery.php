<?php
    require_once('connection.php');
    $conn = connect_to_db();
    if(isset($_GET['CusID'])) {
        $CusID = $_GET['CusID'];
        $getdata = $conn->query("SELECT * FROM cart WHERE maKH like '$CusID'");
        $products = [];
        while ($row = $getdata->fetch_assoc()) {
            $products[] = $row;
        }
        $rand_id = random_int(0, 9999);

        if(isset($_GET['tongtien'])) {
            $tongtien = str_replace(".", "",$_GET['tongtien']);
            
            foreach ($products as $product) {
                $new_id = $rand_id;
                $productName = $product['productName'];
                $productID = $product['productId'];
                $soluong = $product['soluong'];
                
                $today = date('d-m-Y');
                $receiveDate = date('d-m-Y', strtotime('+3 days'));
                $sql = "INSERT INTO delivery (id, maKH,Name, NgayGiao, NgayNhan, status, productID) VALUES ('$new_id', '$CusID','$productName', NOW(), DATE_ADD(NOW(), INTERVAL 3 DAY), 'Processing', '$productID')";
                $update = $conn->query("UPDATE product set sl = sl - '$soluong' WHERE tenSP like '$productName'");
                $PXK =$conn->query("INSERT INTO exportreceipt (maPXK, maKH, ngayXuatKho, tongtien) VALUES ('$new_id', '$CusID', NOW(), '$tongtien')");
                if ($conn->query($sql) === TRUE) {
                    echo "Product added to delivery successfully";
                } else {
                    echo "Error adding product to delivery: " . $conn->error;
                }
                $sql = $conn->query("DELETE FROM cart WHERE maKH = '$CusID'");
            }
            
        }
    }
?>
