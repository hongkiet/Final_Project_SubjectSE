<?php
    require_once('database.php');
    if(isset($_POST['keyword'])) {
        header('Location: search.php?sanpham=' . $_POST['keyword']);
    }
    $CusID = "";
    if(isset($_GET['CusID'])) {
        $CusID = $_GET['CusID'];
        $carts = get_cart_products($CusID);
    }
    
    require_once('CustomerAddress.php');
    $address = getDiaChi();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="SE.css">
    <link rel="stylesheet" href="Banner.css">
    <link rel="stylesheet" href="Notification.css">
    <link rel="stylesheet" href="cart.css">
    <link rel="stylesheet" href="ShowProduct.css">
    <link rel="stylesheet" href="LastLine.css">
    <link rel="stylesheet" href="CheckThanhToan.css">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="navbar-wrapper container-wrapper">
                <nav class="container-navbar">
                <div class="nav-item item-1">
                        <a class="nav-link" style="text-decoration: none;color: #fff;" target="_blank" rel="noopener noreferrer" href="#">Your Profile</a>
                        <span style="font-size: 1.2em;margin-right: 12px;color: #fff;">|</span>
                        <div style="color: #fff;" class="connection">Connect
                            <i style="color: white;font-size: 1.2em;" class="facebook bi bi-facebook"></i>
                        </div>
                    </div>

                    <div class="nav-item item-2">
                        <div class="navbar-text notification">
                            <i class="bi bi-bell"></i>
                            <span>Notification</span>
                            <ul class="show-notification"></ul>
                        </div>
                        <div class="navbar-text support">
                            <i class="bi bi-question-circle"></i>
                            <span>Support</span>
                        </div>
                        <div class="navbar-text language">
                            <i class="bi bi-translate"></i>
                            <span>English</span>
                            <ul class="show-language"></ul>
                        </div>
                        <?php
                            if (isset($_SESSION['name'])){
                        ?>
                            <div class="navbar-text"><?php echo $_SESSION['name'] ?></div>
                            <div class="navbar-text" type="button" onclick="logoutbtn()">Logout</div>
                        <?php 
                            }else{
                        ?> 
                            <div class="navbar-text sign-up">Register</div>
                            <span class="navbar-text" style="font-size: 1.2em;">|</span>
                            <div class="navbar-text sign-in">Sign In</div>
                        <?php
                            }
                        ?>
                    </div>
                </nav>
                <div style="display: flex;">
                    <a style="font-size: 1.5em;
                        text-decoration: none;margin-left: 18%;border: 1px solid #fff;color:#fff;padding: 3px 15px;" href="SE.php">HOME</a>
                    <div style="font-size: 2em;margin-left: 3%;color: #fff;">|</div>
                    <div style="font-size: 2em;margin-left: 3%;color: #fff;">PAYMENT</div>
                </div>
            </div>
        </div>
        <!-- <br><br><br><br><br><br> -->
        <div class="row-3">
            <div class="cart-wrapper" style="width: 100%;">
                <div class="ThanhToan">
                    <div class="location">
                        <i class="bi bi-geo-alt-fill"></i>
                        <div style="margin-left: 0.3%;" class="diachi">Delivery Address</div>
                    </div>
                    <div class="detail-address">
                        <div style="display: flex;margin-left: 3%;font-weight: 500;font-size: 1.1em;">
                            <div class="receiver">Hoàng Anh</div>
                            <div class="phone">(+84) 919017521</div>
                        </div>
                        <div class="address"><?=$address?></div>
                        <div class="change" style="margin-right: 3%;">Change</div>
                        <div class="changeAddress" style="z-index:9999;display:none;position:absolute;
                        width:60vh;margin-left:30%;background-color:orange;padding:10px 20px 10px 20px;">
                                <input style="width:100%;padding:3px 10px 3px 10px" type="text" name="address" id="">
                                <button class="confirmAddress" style="margin-left:2%;">Confirm</button>
                        </div>
                        <script>
                            const address = document.querySelector('.address');
                            const changeBtn = document.querySelector('.change');
                            const changeAddress = document.querySelector('.changeAddress');
                            const inputAddress = document.querySelector('.changeAddress input');
                            const btnAddress = document.querySelector('.confirmAddress');
                                
                            changeBtn.addEventListener('click', () => {
                                changeAddress.style.display = 'flex';
                            });
                                
                            btnAddress.addEventListener('click', () => {
                                if(inputAddress.value != "") {
                                    address.textContent = inputAddress.value;
                                }
                                
                                changeAddress.style.display = 'none';
                            });

                        </script>
                    </div>
                </div>
                <div class="ChotSP">
                    <div class="LastStep">
                        <div class="SPCHOT">
                            <div class="Check-SPCHOT">
                                <label for="ThuocTinhSP">Products</label>
                            </div>
                            <div class="container-SPCHOT">
                                <div class="ChiTiet-SPCHOT">
                                    <div>Price</div>
                                    <div>Quantity</div>
                                    <div>Total</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    $totalPrice = 0;
                    foreach($carts as $c) {
                    ?>
                        <div class="CacSP">
                            <div style="display: flex;width: 30%;">
                                <img class="image-sp" src="./image/<?=$c['productId']?>.jpg" alt="Card image">
                                <div class="TenCacSP"><?=$c['productName']?></div>
                            </div>
                            <div style="display: flex;justify-content: space-between;align-items: center;width: 47%;margin-right:3%;">
                                <div class="DonGia"><?=$c['dongia']?></div>
                                <div class="Selected-SL"><?=$c['soluong']?></div>
                                <div class="total"><?=$c['thanhtien']?></div>
                            </div>
                        </div>
                    <?php
                            $totalPrice += $c['thanhtien'];
                        }
                    ?>

                    <div class="Ship">
                        <div style="display: flex;justify-content: space-between;width: 60%;">
                            <div class="ship-mode">Shipping unit</div>
                            <div>
                                <div class="mode">Fast</div>
                                <div class="date"></div>
                            </div>
                            <div class="change-mode">Change</div>
                            <div class="changeShipMode" style="background-color:#fff;border:1px solid black;display:none;
                            height:10vh;width:30vh;position:absolute;z-index:9999;margin-left:30%;margin-bottom:100px;align-items:center;">
                                <div class="Fast" style="height:50%;background-color:grey;text-align:center;color:#fff;">Fast</div>
                                <div class="Express" style="height:49%;background-color:grey;margin-top:1%;text-align:center;color:#fff;">Express</div>
                            </div>
                            <style>
                                .Fast {
                                    cursor: pointer;
                                }
                                .Express {
                                    cursor: pointer;
                                }
                            </style>
                            
                        </div>
                        <div class="ship-price">37000 VND</div>
                        
                        
                    </div>
                    <div class="final-price">
                        <div style="margin-left: 70%;opacity: 0.7;">Total Amount:</div>
                        <div style="margin-right: 3%;font-size: 1.3em;color: orange;" class="final-money">0 VND</div>
                    </div>
                    

                    <div class="final-Shop-Promotion">
                        <div class="final-Voucher">
                            <i class="bi bi-ticket"></i> 
                            <div style="margin-left: 2%;">Web's Voucher</div>
                        </div>
                        <div class="final-Enter-Voucher">Select Voucher</div>
                        <div class="Voucher-selected" style="display: none;z-index: 9999;position: absolute;">

                        <!-- VOUCHER -->
                            <div class="select-voucher" style="border: 1px solid black;
                            height: 43vh;background-color: white;width: 160vh;margin-left: 60%;margin-top: 30%;">
                                <div style="margin-left: 3%;padding: 20px;">
                                    <div style="font-size: 1.2em;font-weight: 500;">Select Web's Voucher</div>
                                    <div style="display: flex;justify-content: space-between;margin-top: 5%;align-items: center;">
                                        <div>Voucher Code</div>
                                        <input class="input-voucher" style="width: 80%;padding: 10px 5px 10px 5px;"  type="text" name="" id="" placeholder="Web's Voucher">
                                    </div>
                                    <div style="margin-top:5%;">Free Ship Voucher</div>
                                    <div class="free-ship" style="margin-top:2%;margin-left:10%;border:1px solid orange;width:30%;padding:5px 10px 5px 10px;">PHAMTHAIKYTRUNG</div>
                                    <div style="margin-top:5%;">Voucher Discount 50%</div>
                                    <div class="giamgia" style="margin-top:2%;margin-left:10%;border:1px solid orange;width:30%;padding:5px 10px 5px 10px;">TRUNGPHAMCODER</div>
                                    <button style="margin-top:3%;" class="confirm-voucher" type="button">OK</button>
                                </div>
                            </div>
                        </div>
                        <style>
                            .free-ship {
                                cursor: pointer;
                            }
                            .giamgia {
                                cursor: pointer;
                            }
                            .confirm-voucher {
                                width: 50%;
                                margin-left: 25%;
                                padding: 10px 15px 10px 15px;
                                background-color: orangered;
                                color: #fff;
                                font-size: 1.3em;
                                font-weight: 500;
                            }
                        </style>
                        <script>
                            const webVoucher = document.querySelector('.final-Enter-Voucher');
const voucher = document.querySelector('.Voucher-selected');
const Confirmvoucher = document.querySelector('.confirm-voucher');
let isVoucher = true;
webVoucher.addEventListener('click', function() {
        console.log('click');
        isVoucher = false;
        voucher.style.display = "flex"
});
Confirmvoucher.addEventListener('click', () => {
    voucher.style.display = "none";
});
                        </script>
                    </div>
                    <div class="payment">
                        <div style="margin-left: 3%;font-weight: 500;font-size: 1.2em;">PAYMENT METHOD</div>
                        <div style="margin-left: 2%;display: flex;width: 60%;">
                            <div id="TheTD" class="TheTD-not-selected">Credit Card</div>
                            <div id="TheND" class="TheND-not-selected">Local card</div>
                            <div id="Cash" class="Cash-not-selected">Payment on delivery</div>
                            <div id="Momo" class="Momo-not-selected">Payment Momo</div>
                        </div>
                    </div>
                    <div class="payment-mode">

                    </div>
                    <div class="transfer">
                        <div style="margin-left: 70%;">
                            <div style="display: flex;justify-content: space-between;width: 70%;align-items: center;">
                                <div style="opacity: 0.7;">Package amount:</div>
                                <div><?=$totalPrice?>đ</div>
                            </div>
                            <div style="display: flex;justify-content: space-between;width: 70%;align-items: center;">
                                <div style="opacity: 0.7;">Transport fee:</div>
                                <div class="transport-fee">37000 VND</div>
                            </div>
                            <div style="display: flex;justify-content: space-between;align-items: center;width: 70%;margin-top: 1.5%;">
                                <div style="opacity: 0.7;">Total Amount:</div>
                                <div class="chotdeal" style="font-size: 2em;color: orange;">67000 VND</div>
                            </div>
                        </div>
                    </div>
                    <script>
                                
                                const currentDate = new Date();
                                const currentDay = currentDate.getDate();
                                const currentMonth = currentDate.getMonth() + 1; // Tháng bắt đầu từ 0, nên cộng thêm 1
                                const currentYear = currentDate.getFullYear();
                                const futureDate = new Date(currentDate.setDate(currentDate.getDate() + 3));
                                const futureDay = futureDate.getDate();
                                const NextDate = new Date(currentDate.setDate(currentDate.getDate() + 1));
                                const NextDay =NextDate.getDate();

                                const ShipMode =document.querySelector('.mode');
                                const DateElement =document.querySelector('.date');
                                DateElement.innerHTML = `Receive goods on: Th${currentMonth} ${currentDay} - Th${currentMonth} ${futureDay}`
                                const ChangeMode =document.querySelector('.change-mode');
                                const ChangeShipMode =document.querySelector('.changeShipMode');
                                const Fast =document.querySelector('.Fast');
                                const Express =document.querySelector('.Express');
                                const ship_price = document.querySelector('.ship-price');
                                const transportFee =document.querySelector('.transport-fee');
                                ChangeMode.addEventListener('click', () => {
                                    ChangeShipMode.style.display ="block";
                                });
                                const totalPrice = <?=$totalPrice?>;
                                Fast.addEventListener('click', () => {
                                    console.log('click');
                                 
                                    ShipMode.textContent = Fast.textContent;
                                    DateElement.textContent = `Receive goods on: Th${currentMonth} ${currentDay} - Th${currentMonth} ${futureDay}`
                                    ChangeShipMode.style.display ="none";
                                    ship_price.textContent = "37000 VND";
                                    transportFee.textContent = "37000 VND";
                                    totalShip = parseInt(ship_price.textContent.replace(" VND",""));
                                    const newTotalPrice = totalPrice + totalShip;
                                    const final_money =document.querySelector('.final-money');
                                    final_money.textContent =newTotalPrice + "đ";
                                    const chotdeal =document.querySelector('.chotdeal');
                                    chotdeal.textContent =newTotalPrice.toLocaleString('vi-VN');
                                });
                                Express.addEventListener('click', () => {
                                    console.log('click');
                                    
                                    ShipMode.textContent = Express.textContent;
                                    DateElement.textContent = `Receive goods on: Th${currentMonth} ${currentDay} - Th${currentMonth} ${NextDay}`
                                    ChangeShipMode.style.display ="none";
                                    ship_price.textContent = "60000 VND";
                                    transportFee.textContent = "60000 VND";
                                    totalShip = parseInt(ship_price.textContent.replace(" VND",""));
                                    const newTotalPrice = totalPrice + totalShip;
                                    const final_money =document.querySelector('.final-money');
                                    final_money.textContent =newTotalPrice + "đ";
                                    const chotdeal =document.querySelector('.chotdeal');
                                    chotdeal.textContent =newTotalPrice.toLocaleString('vi-VN');
                                });
                                    totalShip = parseInt(ship_price.textContent.replace(" VND",""));
                                    const newTotalPrice = totalPrice + totalShip;
                                    const final_money =document.querySelector('.final-money');
                                    final_money.textContent =newTotalPrice + "đ";
                                    const chotdeal =document.querySelector('.chotdeal');
                                    chotdeal.textContent =newTotalPrice.toLocaleString('vi-VN');


                                    const free_ship =document.querySelector('.free-ship');
const giamgia =document.querySelector('.giamgia');
const selectedVoucher =document.querySelector('.input-voucher');

function handleSelectedVoucher() {
  if (selectedVoucher.value === "PHAMTHAIKYTRUNG") {
    giatrimoi = newTotalPrice - totalShip;
    chotdeal.textContent = giatrimoi.toLocaleString('vi-VN');
  } else if (selectedVoucher.value === "TRUNGPHAMCODER") {
    giatrimoi = newTotalPrice / 2;
    chotdeal.textContent = giatrimoi.toLocaleString('vi-VN');
  } else {
    chotdeal.textContent = newTotalPrice.toLocaleString('vi-VN');
  }
}

free_ship.addEventListener('click', () => {
  selectedVoucher.value = free_ship.textContent;
  handleSelectedVoucher();
});

giamgia.addEventListener('click', () => {
  selectedVoucher.value = giamgia.textContent;
  handleSelectedVoucher();
});

selectedVoucher.addEventListener('input', () => {
  handleSelectedVoucher();
});
                            </script>

                </div>
                <hr style="height: 5px;margin-top: 10%;color: rgb(221, 0, 0)" class="Last-Line">
            </div>
        </div>
    </div>
    
    
      
	
</body>
<script src="SE.js"></script>
<script src="Product.js"></script>

<script>
    const TheTD = document.getElementById('TheTD');
const TheND = document.getElementById('TheND');
const Cash = document.getElementById('Cash');
const Momo = document.getElementById('Momo');
const cha = document.querySelector('.payment-mode');
const div = document.createElement('div');
TheTD.addEventListener('click', () => {
    cha.innerHTML = '';
    TheTD.classList.add('TheTD-selected');
    TheND.classList.remove('TheND-selected');
    Cash.classList.remove('Cash-selected');
    Momo.classList.remove('Momo-selected');
    cha.innerHTML = `
        <div class="Credit-card" style="padding-top: 2%;padding-bottom:2%;"> 
            <div style="border-radius: 3px;width:30%;margin-left:35%;padding:15px;max-height: fit-content;padding-bottom:4%;
            background-color:lightgrey;min-height:55vh;">
                <div style="margin-top: 5%;font-size:1.5em;font-weight:500;">Add card</div>
                <div style="margin-top: 5%;font-size:1.2em;font-weight:400;opacity:0.7;">Card's Detail</div>
                <input style="margin-top: 5%;padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Card's number">
                <div style="display:flex;justify-content:space-between;margin-top:5%;">
                    <input style="padding:10px;width:70%;border-radius:10px;" type="text" placeholder="Expiration date (MM/YY)">
                    <input style="padding:10px;width:25%;border-radius:10px;" type="text" placeholder="CVV Code">
                </div>
                <input style="margin-top: 5%;padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Full Name">
                <div style="margin-top: 5%;">Credit card registration address</div>
                <div style="margin-top: 5%;">
                    <input style="padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Address">
                </div>
                <div style="margin-top: 5%;">
                    <input style="padding:10px;width:100%;border-radius:10px;" type="text" placeholder="Postal code">
                </div>
            </div>
        </div>
    `
});

TheND.addEventListener('click', () => {
    cha.innerHTML = '';
  TheND.classList.add('TheND-selected');
  TheTD.classList.remove('TheTD-selected');
  Cash.classList.remove('Cash-selected');
  Momo.classList.remove('Momo-selected');
  cha.innerHTML = `
    <div class="Bank-type" style="margin-left: 3%;max-height: fit-content;padding-bottom: 3%;">
        <div class="Vietcombank">
            <label for="Vietcombank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Vietcombank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_vietcombank.png" alt="">
                <div style="margin-left:1%;">Vietcombank - Ngân hàng Ngoại Thương</div>
            </label>
        </div>

        <div class="Vietinbank">
            <label for="Vietinbank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Vietinbank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_vietinbank.png" alt="">
                <div style="margin-left:1%;">Vietinbank - Ngân hàng Công Thương</div>
            </label>
        </div>

        <div class="Agribank">
            <label for="Agribank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Agribank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_agribank.png" alt="">
                <div style="margin-left:1%;">Agribank - Ngân hàng Nông Nghiệp</div>
            </label>
        </div>

        <div class="Sacombank">
            <label for="Sacombank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Sacombank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_sacombank.png" alt="">
                <div style="margin-left:1%;">Sacombank - Ngân hàng TMCP Sài Gòn Thương Tín</div>
            </label>
        </div>

        <div class="BIDV">
            <label for="BIDV-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="BIDV-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_bidv.png" alt="">
                <div style="margin-left:1%;">BIDV - Ngân hàng đầu tư và phát triển Việt Nam</div>
            </label>
        </div>

        <div class="TechcomBank">
            <label for="TechcomBank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="TechcomBank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_techcombank.png" alt="">
                <div style="margin-left:1%;">TechcomBank - Ngân hàng Kỹ thương Việt Nam</div>
            </label>
        </div>

        <div class="ACB">
            <label for="ACB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="ACB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_acb.png" alt="">
                <div style="margin-left:1%;">ACB - Ngân hàng ACB</div>
            </label>
        </div>

        <div class="VPBank">
            <label for="VPBank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="VPBank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_vpbank.png" alt="">
                <div style="margin-left:1%;">VPBank - Ngân hàng Việt Nam Thịnh vượng</div>
            </label>
        </div>

        <div class="Đông Á Bank">
            <label for="DongABank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="DongABank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_dongabank.png" alt="">
                <div style="margin-left:1%;">Đông Á Bank - Ngân hàng Đông Á</div>
            </label>
        </div>

        <div class="OceanBankk">
            <label for="OceanBank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="OceanBank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_oceanbank.png" alt="">
                <div style="margin-left:1%;">OceanBank - Ngân hàng Đại Dương</div>
            </label>
        </div>

        <div class="Eximbank">
            <label for="Eximbank-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="Eximbank-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_eximbank.png" alt="">
                <div style="margin-left:1%;">Eximbank - Ngân hàng EximBank</div>
            </label>
        </div>

        <div class="SCB">
            <label for="SCB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="SCB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_scb.png" alt="">
                <div style="margin-left:1%;">SCB - Ngân hàng TMCP Sài Gòn</div>
            </label>
        </div>

        <div class="OCB">
            <label for="OCB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="OCB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_ocb.png" alt="">
                <div style="margin-left:1%;">OCB - Ngân hàng Phương Đông</div>
            </label>
        </div>

        <div class="ABB">
            <label for="ABB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="ABB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_abb.png" alt="">
                <div style="margin-left:1%;">ABB - Ngân hàng TMCP An Bình</div>
            </label>
        </div>

        <div class="MB">
            <label for="MB-input" style="display:flex;padding-top:2%;align-items:center;cursor: pointer;">
                <input id="MB-input" style="transform: scale(1.5);" type="radio" name="bank">
                <img style="margin-left: 1%;border: 1px solid black;padding:10px;" 
                src="https://shopee.vn/static/images/img_bankvn_mb.png" alt="">
                <div style="margin-left:1%;">MB - Ngân hàng Quân Đội</div>
            </label>
        </div>
    </div>
  `
});

Cash.addEventListener('click', () => {
    cha.innerHTML = '';
  Cash.classList.add('Cash-selected');
  TheTD.classList.remove('TheTD-selected');
  TheND.classList.remove('TheND-selected');
  Momo.classList.remove('Momo-selected');
  cha.innerHTML = `
    <div style="display:flex;align-items:center;padding-top:2%;margin-left: 10%;">
        <div style="margin-right:10%;">Payment on delivery</div>
        <div>Household collection fee: ₫0 VND. Preferential shipping fee (if any) also applies to collection fee.</div>
    </div>
  `;
});

Momo.addEventListener('click', () => {
    cha.innerHTML = '';
    Momo.classList.add('Momo-selected');
    Cash.classList.remove('Cash-selected');
    TheTD.classList.remove('TheTD-selected');
    TheND.classList.remove('TheND-selected');
    cha.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;width:160vh;">
        <form style="flex-direction: column;margin-top:1%;width:50%;display:flex;align-items:center;justify-content:center;" method="POST" target="_blank" enctype="application/x-www-form-urlencoded" 
            action="xulythanhtoanmomo.php"
            style="display:flex;align-items:center;padding-top:2%;">
            <input type="hidden" name="amount" value="${chotdeal.textContent}">
                <button style="padding:10px 60px 10px 60px;background-color:orange;color:#fff;font-size:1.2em;
                border:none;border-radius:5px;width:20vh;" class="transfer-QR" type="submit" name="momo">QR</button>
                <div style="opacity:0.5;font-weight:500;">Up to VND 50,000,000</div>
        </form>

        <form style="flex-direction: column;margin-top:1%;width:50%;display:flex;align-items:center;justify-content:center;" method="POST" target="_blank" enctype="application/x-www-form-urlencoded" 
            action="xulythanhtoanmomo_atm.php"
            style="display:flex;align-items:center;padding-top:2%;margin-left: 35%;">
            <input type="hidden" name="amount_atm" value="${chotdeal.textContent}">
            <button style="padding:10px 60px 10px 60px;background-color:orange;color:#fff;font-size:1.2em;
            border:none;border-radius:5px;" class="transfer-ATM" type="submit">ATM</button>
            <div style="opacity:0.5;font-weight:500;">Minimum VND 10,000</div>
        </form>
    </div>
  `;
    const ATM =document.querySelector('.transfer-ATM');
    ATM.addEventListener('click', () => {
        const xhr = new XMLHttpRequest();
        // window.location.assign(`checkdelivery.php?tongtien=${encodeURIComponent(chotdeal.textContent)}`);
        xhr.open('GET', `checkdelivery.php?tongtien=${encodeURIComponent(chotdeal.textContent)}&CusID=${encodeURIComponent(<?=$CusID?>)}`);
        xhr.onload = function() {
            if (xhr.status === 200) {
                console.log('Deleted to cart successfully!');
            } else {
                console.log('Failed to Delete to cart');
            }
        };
        xhr.send();
    });
});
    
const QR =document.querySelector('.momo');
    QR.addEventListener('click', () => {
        const xhr = new XMLHttpRequest();
        // window.location.assign('checkdelivery.php');
        xhr.open('GET', `checkdelivery.php`);
        xhr.onload = function() {
            if (xhr.status === 200) {
                console.log('Deleted to cart successfully!');
            } else {
                console.log('Failed to Delete to cart');
            }
        };
        xhr.send();
    });


function logoutbtn(){
        console.log("Đăng xuất thành công");
        window.location.href = 'logout.php';
    }
</script>
</html>
