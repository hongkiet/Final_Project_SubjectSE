<?php
    require_once('connection.php');
    $conn = connect_to_db();

    $query = $_GET['query'];

    // Query database for suggestions
    $sql = "SELECT * FROM sanpham WHERE tenSP LIKE '%$query%' LIMIT 4";
    $result = $conn->query($sql);

    // Format results as JSON
    $data = array();
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row['tenSP'];
    }
    }
    echo json_encode($data);
?>