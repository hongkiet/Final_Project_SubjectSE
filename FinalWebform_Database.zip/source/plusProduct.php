<?php
    require_once('connection.php');
    $conn = connect_to_db();
    echo $_GET['id'];
    echo $_GET['soluong'];
    echo $_GET['dongia'];
    if (isset($_GET['id'])) {
        $productId = $_GET['id'];
        $soluong = $_GET['soluong'];
        $dongia = $_GET['dongia'];
        $update = $conn->query("UPDATE cart SET soluong = '$soluong', thanhtien = $soluong * $dongia WHERE id like '$productId'");
    }
?>
