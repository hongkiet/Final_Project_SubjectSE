const add = document.querySelector('.Them');
const tru = document.querySelector('.Bot');
const Soluong = document.querySelector('.NhapSoLuong');

add.addEventListener('click', () => {
    console.log('click');
    Soluong.value = parseInt(Soluong.value) + 1;
});
tru.addEventListener('click', () => {
    Soluong.value = parseInt(Soluong.value) - 1;
});

const muangay = document.querySelector('.muangay');
muangay.addEventListener('click', () => {
    window.location.assign('cart.php');
});

