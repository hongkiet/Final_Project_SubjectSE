const stars = document.querySelectorAll('.star');

function highlightStars(star) {
  stars.forEach((star) => {
    star.classList.remove('rated');
  });
  
  for (let i = 0; i < star.dataset.star; i++) {
    stars[i].classList.add('rated');
  }
}

stars.forEach((star) => {
  star.addEventListener('click', () => {
    highlightStars(star);
  });
});