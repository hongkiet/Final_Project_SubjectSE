<?php
    session_start();
    require_once('connection.php');
    function getDiaChi() {
        if(isset($_SESSION['name'])) {
            $conn = connect_to_db();
            $name = $_SESSION['name'];
            $sql = $conn->query("SELECT * FROM customer WHERE TenKH like '$name'");
            $result = $sql->fetch_assoc();
            return $result['DiaChi'];
        }
    }
?>
