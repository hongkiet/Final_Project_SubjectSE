<?php
    require_once('connection.php');
    $conn = connect_to_db();
    echo $_GET['productId'];
    if (isset($_GET['productId'])) {
        $productId = $_GET['productId'];
        $getdata = $conn->query("DELETE FROM cart WHERE id like '$productId'");
    }
?>
