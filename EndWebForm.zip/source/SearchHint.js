const searchBox = document.querySelector('#search-input');
const suggestionsPanel = document.querySelector('#suggestions');

searchBox.addEventListener('input', function() {
  const input = this.value.trim();
  if (input === '') {
    suggestionsPanel.style.display = 'none';
    suggestionsPanel.innerHTML = '';
    return;
  }
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'suggestions.php?query=' + input);
    xhr.onload = function() {
      if (xhr.status === 200) {
        const data = JSON.parse(xhr.responseText);
        suggestionsPanel.innerHTML = '';
        const ul = document.createElement('ul');
        ul.classList.add('suggestions');
        for (let i = 0; i < data.length; i++) {
          const li = document.createElement('li');
          li.classList.add('suggestion');
          li.textContent = data[i];
          li.addEventListener('click', function() {
            searchBox.value = this.textContent;
            suggestionsPanel.style.display = 'none';
          });
          ul.appendChild(li);
        }
        suggestionsPanel.appendChild(ul);
      }
      suggestionsPanel.style.display = 'block';
    };
    xhr.send();
});
