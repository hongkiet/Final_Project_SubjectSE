<?php
    require_once('connection.php');
    $conn = connect_to_db();
    if(isset($_GET['CusID'])) {
        
        $CusID = $_GET['CusID'];
        // echo $CusID;
        $getdata = $conn->query("SELECT * FROM cart WHERE maKH like '$CusID'");
        $products = [];
        while ($row = $getdata->fetch_assoc()) {
            $products[] = $row;
        }
        $rand_id = random_int(0, 9999);
        // var_dump($products);
        if(isset($_GET['tongtien'])) {
            $tongtien = str_replace(".", "",$_GET['tongtien']);
            
            foreach ($products as $product) {
                $new_id = $rand_id;
                $productName = $product['productName'];
                $productID = $product['productId'];
                $soluong = $product['soluong'];
                $Sale = $product['dongia'] * $soluong;
                $today = date('d-m-Y');
                $receiveDate = date('d-m-Y', strtotime('+3 days'));
                $sql = "INSERT INTO delivery (id, maKH,Name, NgayGiao, NgayNhan, status, productID) VALUES ('$new_id', '$CusID','$productName', NOW(), DATE_ADD(NOW(), INTERVAL 3 DAY), 'Processing', '$productID')";
                $update = $conn->query("UPDATE productout set sl = sl - '$soluong' WHERE tenSP like '$productName'");
                $updates = $conn->query("UPDATE product set sl = sl - '$soluong' WHERE tenSP like '$productName'");
                $OriPrice = $Sale / 1.1;
                echo $OriPrice;
                $PXK =$conn->query("INSERT INTO exportreceipt (maPXK, maKH, ngayXuatKho, tongtien, ProductID, soluong, OriPrice, SalePrice) VALUES ('$new_id', '$CusID', NOW(), '$tongtien', '$productID', '$soluong', '$OriPrice','$Sale')");
                if ($conn->query($sql) === TRUE) {
                    echo "Product added to delivery successfully";
                } else {
                    echo "Error adding product to delivery: " . $conn->error;
                }
                
            }
            
        }
        $sql = $conn->query("DELETE FROM cart WHERE maKH = '$CusID'");
        $thongke = $conn->query("INSERT INTO thongke (ProductID, TotalOriPrice, TotalSalePrice, Profit, TotalSale) 
        SELECT ProductID, SUM(OriPrice) as TotalOriPrice, SUM(SalePrice) as TotalSalePrice, (SUM(SalePrice) - SUM(OriPrice)), 
        SUM(soluong) FROM exportreceipt GROUP BY ProductID
        ON DUPLICATE KEY UPDATE TotalSale = VALUES(TotalSale), 
                                TotalOriPrice = VALUES(TotalOriPrice), 
                                TotalSalePrice = VALUES(TotalSalePrice), 
                                Profit = VALUES(Profit)");

        $conn->query("DELETE FROM bestSeller");

        $result = $conn->query("SELECT ProductID, TotalSale FROM thongke ORDER BY TotalSale DESC LIMIT 1");

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $best = $conn->query("INSERT INTO bestSeller (ProductID, TotalQuantity) VALUES ('".$row["ProductID"]."', '".$row["TotalSale"]."')");
        }

    }
?>
