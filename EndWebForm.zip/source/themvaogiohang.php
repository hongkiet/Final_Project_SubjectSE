<?php
    session_start();
    require_once('connection.php');
    if(isset($_GET['Cus'])) {
        $conn = connect_to_db();
        $getCusName = $_GET['Cus'];
        $CusInfo = ("SELECT * FROM customer where TaiKhoan like '$getCusName'");
        $stm = $conn->prepare($CusInfo);
        if(!$stm->execute()) {
            return array('code' => 2, 'error' => 'Không thể thực thi câu lệnh');
        }
        $CusResult = $stm->get_result();
        $CusData = $CusResult->fetch_assoc();
        $CusID = $CusData['MaKH'];
        echo $CusID;
        if (isset($_GET['productName']) && isset($_GET['soluong'])) {
            $productName = $_GET['productName'];
            $getdata = $conn->query("SELECT * FROM productout WHERE tenSP like '$productName'");
            $products = [];
            while ($row = $getdata->fetch_assoc()) {
                $products[] = $row;
            }
            print_r($products);
            $Maxid = 'SELECT MAX(id) as max_id FROM cart';
                $stm = $conn->prepare($Maxid);
                if(!$stm->execute()) {
                    return array('code' => 2, 'error' => 'Không thể thực thi câu lệnh');
                }
            $result = $stm->get_result();
            $data = $result->fetch_assoc();
            $maxid = $data['max_id'];
            foreach ($products as $product) {
                $new_id = (int)$maxid + 1;
                $productId = $product['maSP'];
                echo $productId;
                $productName = $product['tenSP'];
                $dongia = $product['dongia'];
                $soluong = $_GET['soluong']; // Số lượng mặc định là 1
                $sql = "INSERT INTO cart (id, maKH, productId, productName, dongia, soluong, thanhtien) VALUES ('$new_id', '$CusID','$productId', '$productName', '$dongia', '$soluong', $soluong * $dongia)";

                if ($conn->query($sql) === TRUE) {
                    echo "Product added to cart successfully";
                } else {
                    echo "Error adding product to cart: " . $conn->error;
                }
            }
        }
    }
?>
