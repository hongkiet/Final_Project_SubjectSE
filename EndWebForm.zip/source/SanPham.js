const addToCartBtn = document.querySelector('.themvaogiohang');
    addToCartBtn.addEventListener('click', () => {
        const productName = addToCartBtn.dataset.name;
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'themvaogiohang.php');
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                console.log('Added to cart successfully!');
            } else {
                console.log('Failed to add to cart');
            }
        };
        xhr.send(`productName=${productName}`);
    });