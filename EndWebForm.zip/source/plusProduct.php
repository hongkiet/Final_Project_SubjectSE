<?php
    require_once('connection.php');
    
    
    if (isset($_GET['id']) && isset($_GET['soluong']) && isset($_GET['dongia'])) {
        $conn = connect_to_db();
        echo $_GET['id'];
        $productId = $_GET['id'];
        $soluong = $_GET['soluong'];
        $dongia = $_GET['dongia'];
        $update = $conn->query("UPDATE cart SET soluong = $soluong, thanhtien = ($soluong * $dongia) WHERE id = '$productId'");


    }
?>
