<?php
    require_once('connection.php');
    $conn = connect_to_db();
    if (isset($_GET['productName']) && isset($_GET['soluong'])) {
        $productName = $_GET['productName'];
        $getdata = $conn->query("SELECT * FROM productout WHERE tenSP like '$productName'");
        $products = [];
        while ($row = $getdata->fetch_assoc()) {
            $products[] = $row;
        }
        print_r($products);
        $Maxid = 'SELECT MAX(id) as max_id FROM cart';
            $stm = $conn->prepare($Maxid);
            if(!$stm->execute()) {
                return array('code' => 2, 'error' => 'Không thể thực thi câu lệnh');
            }
        $result = $stm->get_result();
        $data = $result->fetch_assoc();
        $maxid = $data['max_id'];
        foreach ($products as $product) {
            $new_id = (int)$maxid + 1;
            $productId = $product['maSP'];
            echo $productId;
            $productName = $product['tenSP'];
            $dongia = $product['dongia'];
            $soluong = $_GET['soluong']; // Số lượng mặc định là 1
            $sql = "INSERT INTO cart (id,productId, productName, dongia, soluong) VALUES ('$new_id','$productId', '$productName', '$dongia', '$soluong')";

            if ($conn->query($sql) === TRUE) {
                echo "Product added to cart successfully";
            } else {
                echo "Error adding product to cart: " . $conn->error;
            }
        }
    }
?>
