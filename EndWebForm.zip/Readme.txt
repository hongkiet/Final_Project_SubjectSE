1. Access to http://localhost/phpmyadmin/ then import file database.sql
2. About webform:
in folder source, open file SE.php this is the main file of the webform.
Register an account, then log in into the website (you must log in to purchase products).
Click products display on the main page or search the name of the products (now you are in SanPham.php).
In SanPham.php you can see the detail information of the product. Especially, you can add products to cart. Click cart button to check the products that you added to cart, click Purchase button to buy product. After click Purchase in cart.php, you will be redirected to checkthanhtoan.php, in this page you can check the total amount of the products, you can also choose ship-mode (fast or express). Furthermore, you can choose Voucher to have our promotion. After check the price, now you choose the payment method( Choose Payment Momo then choose ATM can only pay orders under 50 million VND) then you fill these information to complete the payment:
	+Card Number:9704 0000 0000 0018
	+Date: 03/07
	+Name:NGUYEN VAN A
	+Phone: 0919100100
	=> Then you enter OTP code: OTP
Finally, Payment successful now you can see the status of the products that you purchased and the day you can receive the package.
